package part1;

import javax.swing.JOptionPane;//

public class Mycourse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//declare player
		//accepts and prints player's name
		String player;
		player = ("");

		String output;
		player = JOptionPane.showInputDialog("Enter player's name");
		output = "Let's play matching pennies " + player;
		JOptionPane.showMessageDialog(null, output, "", JOptionPane.INFORMATION_MESSAGE);
		
		
		// declares player choice
		//accepts player choice odd or even
		String playerChoice;
		 playerChoice = JOptionPane.showInputDialog("Pick a side odd OR even");
		
		// declares player Pennies
		// accept number of player Pennies
		//converts userPennies String to integer
		String userPennies;
		userPennies = JOptionPane.showInputDialog("enter number of pennies");
		int x = Integer.parseInt(userPennies);

		//allows player pick a side odd or even
		//validates the entry
		switch ( playerChoice) {
		case "even":
			break;
		case "odd":
			break;

		default:
			 playerChoice = JOptionPane.showInputDialog("ENTRY ERROR Select odd or even");

		}
		System.out.println("player's choice " + playerChoice);
		
		
       //declare results for odd or even
		//start the loop
		
		int resultOdd = 0;

		int resultEven = 0;

		int counter = 0;
		do {

			// declare coin and allow player enter his choice tail or head
			// validates the entry  made
		
			String playerCoin;
			playerCoin = JOptionPane.showInputDialog("toss your coin.head or tail");

			switch (playerCoin) {
			case "tail":
				break;
			case "head":
				break;
			default:

				playerCoin = JOptionPane.showInputDialog("ENTRY ERROR Select head or tail "); 
			} // ends switch
			System.out.println("player toss " +playerCoin);// print player's choice
			

			// declare coin options for computer using String and array
			// Allows the computer pick a coin randomly
			// print computer choice
			String coin[] = { "head", "tail" };
			int computerChoice = (int) (Math.random() * coin.length);
			String computerCoin = coin[computerChoice];
			System.out.println("computer toss " + computerCoin);

			// compares player and computer coins
			// declare and print winner per loop if conditions are met
			// sums all even results
			if (playerCoin.equals(computerCoin)) { 	
			
				String winner;
				winner = "even won this round";
				JOptionPane.showMessageDialog(null, winner, "", JOptionPane.INFORMATION_MESSAGE);				
				System.out.println("even gets +1 coin");
				resultEven++;

				// if above not true print winner below
				// sums all odd results
			} else {
				String winner;
				winner = "odd won this round";
				JOptionPane.showMessageDialog(null, winner, "", JOptionPane.INFORMATION_MESSAGE);
				System.out.println("odd gets  +1 coin");
				resultOdd++;// sums all odd results
			} 	// end if else
			
			
				// allows player play/loop x times before printing winner
			counter++;
		} while (counter <= x); 
		
				// compare results if even is greater than odd 
		        // print winner 
		
		if (resultEven > resultOdd) {
			System.out.println("even won the game");

		} else {
			System.out.println("odd won the game");

		} 		// end if/else
		
		
			}
} // end class
